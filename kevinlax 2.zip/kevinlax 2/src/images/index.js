import logo from "./logo.png";
import heroImg from "./heroImg.png";
import kevinlaxLogo from "./kevinlaxLogo.png";
import kevinlaxMobileLogo from "./kevinlaxMobileLogo.png";
import bg1 from "./bg1.png";
import bg2 from "./bg2.png";
import bg3 from "./bg3.png";
import soundCloud from "./soundCloud.png";
import spotify from "./spotify.png";
import imdb from "./imdb.png";
import instagram from "./instagram.png";
import image1 from "./1.png";
import image2 from "./2.png";
import image3 from "./3.png";
import image4 from "./4.png";
import image5 from "./5.png";
import image6 from "./6.png";
import image7 from "./7.png";
import image8 from "./8.png";
import image9 from "./9.png";
import image10 from "./10.png";
import image11 from "./11.png";
import image12 from "./12.png";
import image13 from "./13.png";
import image14 from "./14.png";
import image15 from "./15.png";
import image16 from "./16.png";
import biograpy from "./biography.png";
import netflix from "./netflix.png";
import ea from "./ea.png";
import universal from "./universal.png";
import dreamWorks from "./dreamworks.png";
import appleTv from "./appleTv.png";
import footerBg from "./footerBg.png";

export {
  logo,
  heroImg,
  kevinlaxLogo,
  kevinlaxMobileLogo,
  bg1,
  bg2,
  bg3,
  soundCloud,
  spotify,
  imdb,
  instagram,
  image1,
  image2,
  image3,
  image4,
  image5,
  image6,
  image7,
  image8,
  image9,
  image10,
  image11,
  image12,
  image13,
  image14,
  image15,
  image16,
  netflix,
  biograpy,
  ea,
  universal,
  dreamWorks,
  appleTv,
  footerBg,
};
